﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PermissionMaking.ASP.NET.MVC.Areas.Test.Controllers
{
    public class MainController : Controller
    {
        // GET: Test/Main
        public ActionResult Index()
        {
            return View();
        }
    }
}